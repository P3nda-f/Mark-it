import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface Facility {
  name: string;
  address: string;
  accessibilityFeatures: string[];
  rating: number;
  placeId: string;
  description: string;
  mapsUri?: string;
}

export async function findNearbyFacilities(lat: number, lng: number, query: string = "accessible facilities"): Promise<{ text: string; facilities: Facility[]; sources: any[] }> {
  const model = "gemini-2.5-flash";
  
  const prompt = `Find nearby ${query} at coordinates ${lat}, ${lng}. 
  Focus on accessibility features like wheelchair ramps, elevators, accessible restrooms, and tactile paving.
  Return a list of facilities with their names, addresses, and specific accessibility features.
  Be helpful and descriptive about the accessibility of each place.`;

  const response = await ai.models.generateContent({
    model,
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    config: {
      tools: [{ googleMaps: {} }],
      toolConfig: {
        retrievalConfig: {
          latLng: {
            latitude: lat,
            longitude: lng
          }
        }
      }
    },
  });

  const text = response.text || "";
  const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  
  // Extract facilities from grounding chunks if they exist
  const facilities: Facility[] = groundingChunks
    .filter((chunk: any) => chunk.maps)
    .map((chunk: any) => ({
      name: chunk.maps.title || "Facility",
      address: chunk.maps.uri || "",
      accessibilityFeatures: ["Accessible Entrance", "Elevator Access"], // Defaulting to accessible features
      rating: 4.5,
      placeId: chunk.maps.uri,
      description: "Accessible facility found via Google Maps grounding.",
      mapsUri: chunk.maps.uri
    }));
  
  return {
    text,
    facilities,
    sources: groundingChunks
  };
}

export async function getIndoorDirections(facilityName: string, destinationRoom: string, currentPosition: string): Promise<string> {
  const model = "gemini-3-flash-preview";
  
  const prompt = `You are an expert indoor navigation assistant for people with disabilities.
  Facility: ${facilityName}
  Current Location: ${currentPosition}
  Destination: ${destinationRoom}
  
  Provide a detailed, step-by-step accessible route. 
  Rules:
  1. ALWAYS prefer elevators over stairs.
  2. Mention landmarks (e.g., "pass the information desk on your left").
  3. Specify door types (e.g., "automatic sliding doors").
  4. Use clear directional language (left, right, straight).
  5. If you don't have the exact map, describe a typical accessible path for this type of building (e.g., hospital, library).
  6. Keep instructions concise but highly descriptive for accessibility.
  
  Format the output with clear steps using Markdown.`;

  const response = await ai.models.generateContent({
    model,
    contents: [{ role: "user", parts: [{ text: prompt }] }],
  });

  return response.text || "I'm sorry, I couldn't generate the navigation steps. Please ask a staff member for assistance.";
}
