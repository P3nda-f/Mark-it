import React, { useState, useEffect } from 'react';
import { MapPin, Search, Navigation, Calendar, Info, ChevronRight, Accessibility, ArrowLeft, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { findNearbyFacilities, getIndoorDirections, Facility } from './services/gemini';
import ReactMarkdown from 'react-markdown';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

type AppMode = 'search' | 'facility-detail' | 'navigate' | 'book' | 'about';

export default function App() {
  const [mode, setMode] = useState<AppMode>('search');
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [facilities, setFacilities] = useState<any>(null);
  const [selectedFacility, setSelectedFacility] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [indoorDirections, setIndoorDirections] = useState<string | null>(null);
  const [destinationRoom, setDestinationRoom] = useState('');
  const [navStep, setNavStep] = useState(0);
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const googleMapsApiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Error getting location:", error);
          // Fallback location (e.g., San Francisco)
          setLocation({ lat: 37.7749, lng: -122.4194 });
        }
      );
    }
  }, []);

  const handleSearch = async () => {
    if (!location) return;
    setLoading(true);
    try {
      const results = await findNearbyFacilities(location.lat, location.lng, searchQuery || "accessible facilities");
      setFacilities(results);
    } catch (error) {
      console.error("Search failed:", error);
    } finally {
      setLoading(false);
    }
  };

  const startNavigation = async () => {
    if (!selectedFacility || !destinationRoom) return;
    setLoading(true);
    setMode('navigate');
    setNavStep(0);
    try {
      const directions = await getIndoorDirections(selectedFacility.name, destinationRoom, "Main Entrance");
      setIndoorDirections(directions);
    } catch (error) {
      console.error("Navigation failed:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-black/5 sticky top-0 z-50 px-6 py-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div 
            className="flex items-center gap-2 cursor-pointer" 
            onClick={() => {
              setMode('search');
              setSelectedFacility(null);
              setIndoorDirections(null);
            }}
          >
            <div className="w-10 h-10 bg-black rounded-xl flex items-center justify-center">
              <MapPin className="text-white w-6 h-6" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight">mark-it</h1>
          </div>
          
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setMode('about')}
              className="text-sm font-semibold hover:text-emerald-600 transition-colors"
            >
              How it works
            </button>
            <button className="p-2 hover:bg-zinc-100 rounded-full transition-colors" aria-label="Accessibility Settings">
              <Accessibility className="w-6 h-6" />
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-4xl mx-auto w-full p-6">
        <AnimatePresence mode="wait">
          {mode === 'about' && (
            <motion.div
              key="about"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <button 
                onClick={() => setMode('search')}
                className="flex items-center gap-2 text-zinc-500 hover:text-black transition-colors font-medium"
              >
                <ArrowLeft className="w-4 h-4" /> Back to search
              </button>

              <section className="space-y-6">
                <h2 className="text-4xl font-bold tracking-tight">How mark-it Works</h2>
                <p className="text-zinc-500 text-lg">
                  mark-it is designed to bridge the gap between outdoor maps and indoor reality for people with disabilities.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="accessible-card space-y-4">
                    <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                      <Search className="text-emerald-600 w-5 h-5" />
                    </div>
                    <h3 className="text-xl font-bold">1. Finding Facilities</h3>
                    <p className="text-zinc-500 text-sm">
                      We use the <strong>Gemini API with Google Maps Grounding</strong>. When you search, the AI queries real-time map data to find facilities that match your accessibility needs.
                    </p>
                  </div>

                  <div className="accessible-card space-y-4">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Navigation className="text-blue-600 w-5 h-5" />
                    </div>
                    <h3 className="text-xl font-bold">2. Indoor Navigation</h3>
                    <p className="text-zinc-500 text-sm">
                      Once at a facility, we use <strong>Gemini 3 Flash</strong> to generate precise indoor routes. It prioritizes elevators, wide corridors, and accessible entrances based on building layouts.
                    </p>
                  </div>

                  <div className="accessible-card space-y-4">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <Accessibility className="text-purple-600 w-5 h-5" />
                    </div>
                    <h3 className="text-xl font-bold">3. Accessibility First</h3>
                    <p className="text-zinc-500 text-sm">
                      The entire app is built with high-contrast UI, large touch targets, and descriptive language to ensure it's usable for everyone.
                    </p>
                  </div>

                  <div className="accessible-card space-y-4">
                    <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                      <Calendar className="text-orange-600 w-5 h-5" />
                    </div>
                    <h3 className="text-xl font-bold">4. Room Booking</h3>
                    <p className="text-zinc-500 text-sm">
                      Integrated booking allows users to reserve accessible rooms in advance, ensuring their needs are met before they even arrive.
                    </p>
                  </div>
                </div>

                <div className="bg-zinc-900 text-white p-8 rounded-3xl space-y-4">
                  <h3 className="text-2xl font-bold">Implementation Guide</h3>
                  <p className="text-zinc-400">To enable real map previews, follow these steps:</p>
                  <ol className="list-decimal list-inside text-zinc-400 space-y-4">
                    <li>
                      <strong>Get a Google Maps API Key:</strong> 
                      Go to the <a href="https://console.cloud.google.com/google/maps-apis/credentials" target="_blank" className="text-emerald-400 underline">Google Cloud Console</a> and create a new project or select an existing one.
                    </li>
                    <li>
                      <strong>Enable APIs:</strong> 
                      Enable the <strong>Maps Embed API</strong> and the <strong>Maps JavaScript API</strong> for your project.
                    </li>
                    <li>
                      <strong>Add the Key:</strong> 
                      In AI Studio, add a new secret named <code>VITE_GOOGLE_MAPS_API_KEY</code> with your API key as the value.
                    </li>
                    <li>
                      <strong>Restart:</strong> 
                      The app will automatically pick up the key and start rendering real maps!
                    </li>
                  </ol>
                </div>
              </section>
            </motion.div>
          )}

          {mode === 'search' && (
            <motion.div
              key="search"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <section className="space-y-4">
                <h2 className="text-4xl font-bold tracking-tight leading-tight">
                  Find accessible spaces <br />
                  <span className="text-emerald-600">designed for everyone.</span>
                </h2>
                <p className="text-zinc-500 text-lg max-w-xl">
                  Search for nearby facilities with wheelchair access, elevators, and tactile navigation.
                </p>
              </section>

              <div className="relative group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400 group-focus-within:text-black transition-colors" />
                <input
                  type="text"
                  placeholder="Search for hospitals, libraries, malls..."
                  className="w-full pl-12 pr-4 py-4 bg-white border-2 border-black/5 rounded-2xl text-lg focus:border-black outline-none transition-all shadow-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                />
                <button 
                  onClick={handleSearch}
                  disabled={loading}
                  className="absolute right-2 top-2 bottom-2 bg-black text-white px-6 rounded-xl font-semibold hover:bg-zinc-800 transition-colors disabled:opacity-50"
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Search'}
                </button>
              </div>

              {facilities && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-bold">Nearby Facilities</h3>
                    <div className="flex bg-zinc-100 p-1 rounded-xl">
                      <button 
                        onClick={() => setViewMode('list')}
                        className={cn("px-4 py-1.5 rounded-lg text-sm font-bold transition-all", viewMode === 'list' ? "bg-white shadow-sm" : "text-zinc-500")}
                      >
                        List
                      </button>
                      <button 
                        onClick={() => setViewMode('map')}
                        className={cn("px-4 py-1.5 rounded-lg text-sm font-bold transition-all", viewMode === 'map' ? "bg-white shadow-sm" : "text-zinc-500")}
                      >
                        Map
                      </button>
                    </div>
                  </div>
                  
                  {facilities.text && (
                    <div className="prose prose-zinc max-w-none mb-8 bg-emerald-50 p-6 rounded-2xl border border-emerald-100">
                      <ReactMarkdown>{facilities.text}</ReactMarkdown>
                    </div>
                  )}

                  {viewMode === 'list' ? (
                    <div className="grid grid-cols-1 gap-4">
                      {(facilities.facilities.length > 0 ? facilities.facilities : facilities.sources).map((item: any, idx: number) => {
                        const name = item.name || item.web?.title || item.maps?.title || "Nearby Facility";
                        const uri = item.mapsUri || item.maps?.uri || "";
                        
                        return (
                          <button
                            key={idx}
                            onClick={() => {
                              setSelectedFacility({
                                name,
                                address: uri,
                                uri
                              });
                              setMode('facility-detail');
                            }}
                            className="accessible-card text-left flex items-center justify-between group"
                          >
                            <div className="space-y-1">
                              <h4 className="font-bold text-lg group-hover:text-emerald-600 transition-colors">
                                {name}
                              </h4>
                              <p className="text-zinc-500 text-sm flex items-center gap-1">
                                <MapPin className="w-3 h-3" />
                                {uri ? 'View on Maps' : 'Accessible Facility'}
                              </p>
                            </div>
                            <ChevronRight className="w-6 h-6 text-zinc-300 group-hover:text-black transition-colors" />
                          </button>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="accessible-card h-[500px] bg-zinc-50 relative overflow-hidden p-0">
                      {googleMapsApiKey ? (
                        <iframe
                          width="100%"
                          height="100%"
                          style={{ border: 0 }}
                          loading="lazy"
                          allowFullScreen
                          referrerPolicy="no-referrer-when-downgrade"
                          src={`https://www.google.com/maps/embed/v1/search?key=${googleMapsApiKey}&q=${encodeURIComponent(searchQuery || "accessible facilities")}&center=${location?.lat},${location?.lng}&zoom=14`}
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center space-y-4">
                          <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center">
                            <MapPin className="text-emerald-600 w-8 h-8" />
                          </div>
                          <h4 className="text-xl font-bold">Map Preview Unavailable</h4>
                          <p className="text-zinc-500 max-w-sm">
                            To see an interactive map, please add your <strong>Google Maps API Key</strong> in the settings.
                          </p>
                          <button 
                            onClick={() => setMode('about')}
                            className="text-emerald-600 font-bold hover:underline"
                          >
                            Learn how to enable maps →
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          )}

          {mode === 'facility-detail' && selectedFacility && (
            <motion.div
              key="detail"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <button 
                onClick={() => setMode('search')}
                className="flex items-center gap-2 text-zinc-500 hover:text-black transition-colors font-medium"
              >
                <ArrowLeft className="w-4 h-4" /> Back to results
              </button>

              <div className="space-y-4">
                <h2 className="text-4xl font-bold tracking-tight">{selectedFacility.name}</h2>
                <div className="flex flex-wrap gap-2">
                  <span className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-sm font-semibold flex items-center gap-1">
                    <Accessibility className="w-4 h-4" /> Wheelchair Accessible
                  </span>
                  <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-semibold flex items-center gap-1">
                    <Info className="w-4 h-4" /> Elevator Available
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="accessible-card space-y-4">
                  <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                    <Navigation className="text-emerald-600 w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold">Indoor Navigation</h3>
                  <p className="text-zinc-500">
                    Get precise, accessible directions to specific rooms or departments within this facility.
                  </p>
                  <div className="space-y-2">
                    <label className="text-sm font-bold uppercase tracking-wider text-zinc-400">Destination Room</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Room 302, Radiology, Cafe"
                      className="w-full p-3 bg-zinc-50 border border-black/5 rounded-xl focus:border-black outline-none transition-all"
                      value={destinationRoom}
                      onChange={(e) => setDestinationRoom(e.target.value)}
                    />
                  </div>
                  <button 
                    onClick={startNavigation}
                    disabled={!destinationRoom || loading}
                    className="btn-primary w-full"
                  >
                    {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Start Indoor Navigation'}
                  </button>
                </div>

                <div className="accessible-card space-y-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <Calendar className="text-blue-600 w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold">Book a Room</h3>
                  <p className="text-zinc-500">
                    Need a private space or a consultation room? Reserve an accessible room in advance.
                  </p>
                  <button 
                    onClick={() => setMode('book')}
                    className="btn-secondary w-full"
                  >
                    Check Availability
                  </button>
                </div>
              </div>
              
              {selectedFacility.name && (
                <div className="rounded-2xl overflow-hidden border border-black/5 h-80 bg-zinc-100 relative">
                  {googleMapsApiKey ? (
                    <iframe
                      width="100%"
                      height="100%"
                      style={{ border: 0 }}
                      loading="lazy"
                      allowFullScreen
                      referrerPolicy="no-referrer-when-downgrade"
                      src={`https://www.google.com/maps/embed/v1/place?key=${googleMapsApiKey}&q=${encodeURIComponent(selectedFacility.name)}`}
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center space-y-2">
                       <MapPin className="text-zinc-300 w-12 h-12" />
                       <p className="text-zinc-400 font-medium">Map Preview for {selectedFacility.name}</p>
                       <p className="text-zinc-400 text-xs">Add a Google Maps API Key to see real maps.</p>
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          )}

          {mode === 'navigate' && (
            <motion.div
              key="navigate"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-6"
            >
              <div className="flex items-center justify-between">
                <button 
                  onClick={() => setMode('facility-detail')}
                  className="flex items-center gap-2 text-zinc-500 hover:text-black transition-colors font-medium"
                >
                  <ArrowLeft className="w-4 h-4" /> Exit Navigation
                </button>
                <div className="px-4 py-2 bg-emerald-100 text-emerald-700 rounded-full text-sm font-bold animate-pulse">
                  Live Navigation Active
                </div>
              </div>

              <div className="bg-black text-white p-8 rounded-3xl shadow-2xl space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center animate-bounce">
                    <Navigation className="text-black w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold">Navigating to {destinationRoom}</h2>
                    <p className="text-emerald-400 font-medium">Current Location: Main Entrance</p>
                  </div>
                </div>

                <div className="h-1 bg-zinc-800 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-emerald-500"
                    initial={{ width: "0%" }}
                    animate={{ width: "35%" }}
                    transition={{ duration: 2 }}
                  />
                </div>

                <div className="prose prose-invert max-w-none bg-zinc-900 p-6 rounded-2xl border border-white/10">
                  {loading ? (
                    <div className="flex items-center justify-center py-12">
                      <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
                    </div>
                  ) : (
                    <ReactMarkdown>{indoorDirections || ""}</ReactMarkdown>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <button 
                    onClick={() => setNavStep(Math.max(0, navStep - 1))}
                    disabled={navStep === 0}
                    className="bg-zinc-800 hover:bg-zinc-700 p-4 rounded-xl font-bold transition-colors disabled:opacity-50"
                  >
                    Previous Step
                  </button>
                  <button 
                    onClick={() => setNavStep(navStep + 1)}
                    className="bg-emerald-500 hover:bg-emerald-400 text-black p-4 rounded-xl font-bold transition-colors"
                  >
                    Next Step
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {mode === 'book' && (
            <motion.div
              key="book"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <button 
                onClick={() => setMode('facility-detail')}
                className="flex items-center gap-2 text-zinc-500 hover:text-black transition-colors font-medium"
              >
                <ArrowLeft className="w-4 h-4" /> Back to facility
              </button>

              <div className="space-y-2">
                <h2 className="text-4xl font-bold tracking-tight">Book a Room</h2>
                <p className="text-zinc-500">Reserve an accessible space at {selectedFacility?.name}</p>
              </div>

              <div className="accessible-card space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold uppercase tracking-wider text-zinc-400">Date</label>
                    <input type="date" className="w-full p-4 bg-zinc-50 border border-black/5 rounded-xl focus:border-black outline-none" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold uppercase tracking-wider text-zinc-400">Time</label>
                    <input type="time" className="w-full p-4 bg-zinc-50 border border-black/5 rounded-xl focus:border-black outline-none" />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold uppercase tracking-wider text-zinc-400">Room Type</label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {['Quiet Room', 'Consultation', 'Study Space'].map((type) => (
                      <button key={type} className="p-4 border-2 border-black/5 rounded-xl hover:border-emerald-500 hover:bg-emerald-50 transition-all font-bold">
                        {type}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl flex gap-3">
                  <Info className="text-blue-600 w-5 h-5 shrink-0" />
                  <p className="text-sm text-blue-800">
                    All rooms are equipped with adjustable height desks and are wheelchair accessible.
                  </p>
                </div>

                <button 
                  onClick={() => {
                    alert("Booking confirmed! We've sent the details to your email.");
                    setMode('facility-detail');
                  }}
                  className="btn-primary w-full py-4 text-lg"
                >
                  Confirm Reservation
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-black/5 px-6 py-8 mt-12">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2 opacity-50">
            <MapPin className="w-5 h-5" />
            <span className="font-bold tracking-tight">mark-it</span>
          </div>
          <p className="text-zinc-400 text-sm text-center md:text-right">
            Built with care for family and community. <br />
            Empowering accessibility through AI.
          </p>
        </div>
      </footer>
    </div>
  );
}
